<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<meta charset="utf-8">
		<!-- JS -->
		<script type="text/javascript" src="includes/js/jquery-3.2.0.min.js"></script>
		<script type="text/javascript" src="includes/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="includes/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="includes/css/estilo.css">
	</head>
	<body>
