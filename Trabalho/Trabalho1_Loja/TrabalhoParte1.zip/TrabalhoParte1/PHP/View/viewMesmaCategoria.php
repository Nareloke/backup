<?php
    include_once $_SESSION["root"]."Includes/head.php";
    include_once $_SESSION["root"]."Includes/header.php";
    include_once $_SESSION["root"]."Includes/nav.php";
    include_once $_SESSION["root"]."PHP/View/mesma-categoria/breadcrumb.php";
    include_once $_SESSION["root"]."PHP/View/mesma-categoria/section.php";
    include_once $_SESSION["root"]."Includes/footer.php";