<?php
    include_once $_SESSION["root"]."Includes/head.php";
    include_once $_SESSION["root"]."Includes/header.php";
    include_once $_SESSION["root"]."Includes/nav.php";
    include_once $_SESSION["root"]."PHP/View/product-Page/2-breadcrumb.php";
    include_once $_SESSION["root"]."PHP/View/product-Page/3-section.php";
    include_once $_SESSION["root"]."PHP/View/product-Page/4-section.php";
    include_once $_SESSION["root"]."Includes/footer.php";
?>