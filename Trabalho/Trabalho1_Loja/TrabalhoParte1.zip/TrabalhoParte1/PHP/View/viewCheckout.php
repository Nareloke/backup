<?php
    include_once $_SESSION["root"]."Includes/head.php";
    include_once $_SESSION["root"]."Includes/header.php";
    include_once $_SESSION["root"]."Includes/nav.php";
    include_once $_SESSION["root"]."PHP/View/checkout/1-breadCrumb.php";
    include_once $_SESSION["root"]."PHP/View/checkout/2-billingDetails.php";
    include_once $_SESSION["root"]."PHP/View/checkout/3-shippingMethods.php";
    include_once $_SESSION["root"]."PHP/View/checkout/4-orderReview.php";
    include_once $_SESSION["root"]."Includes/footer.php";
?>