	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">

            <?php
                include_once $_SESSION["root"]."PHP/View/mesma-categoria/aside.php";
                include_once $_SESSION["root"]."PHP/View/mesma-categoria/main.php";
            ?>

			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->