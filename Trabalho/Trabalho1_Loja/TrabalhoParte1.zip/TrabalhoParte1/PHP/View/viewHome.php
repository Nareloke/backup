<?php
    include_once $_SESSION["root"]."Includes/head.php";
    include_once $_SESSION["root"]."Includes/header.php";
    include_once $_SESSION["root"]."PHP/View/home/navigation.php";
    include_once $_SESSION["root"]."PHP/View/home/home.php";
    include_once $_SESSION["root"]."PHP/View/home/section.php";
    include_once $_SESSION["root"]."PHP/View/home/section2.php";
    include_once $_SESSION["root"]."PHP/View/home/section3.php";
    include_once $_SESSION["root"]."PHP/View/home/section4.php";
    include_once $_SESSION["root"]."Includes/footer.php";
?>