	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">

            <?php
                include_once $_SESSION["root"]."PHP/View/products/aside.php";
                include_once $_SESSION["root"]."PHP/View/products/main.php";
            ?>

			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->