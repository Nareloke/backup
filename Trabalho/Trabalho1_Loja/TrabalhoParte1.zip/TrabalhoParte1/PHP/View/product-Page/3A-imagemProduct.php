<div class="col-md-6">
    <div id="product-main-view">
        <div class="product-view">
            <img src="<?= $requisaoJSON->imagem ?>" alt="">
        </div>
    </div>
</div>
